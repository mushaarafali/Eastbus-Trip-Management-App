class StaffSession {
  final int id; final String fullName; final String role; final String loginId; final String phone; final String email; final int operatorId;
  StaffSession({required this.id,required this.fullName,required this.role,required this.loginId,required this.phone,required this.email,required this.operatorId});
  factory StaffSession.fromJson(Map<String,dynamic> j)=>StaffSession(id:_i(j['id']),fullName:'${j['full_name']??''}',role:'${j['role']??''}',loginId:'${j['login_id']??''}',phone:'${j['phone']??''}',email:'${j['email']??''}',operatorId:_i(j['operator_id']));
  static int _i(dynamic v)=>int.tryParse('$v')??0;
}
