class TripPassenger {
  final int id;
  final String seatNumber;
  final String passengerName;
  final String gender;
  final String? primaryNic;
  final bool checkedIn;

  const TripPassenger({
    required this.id,
    required this.seatNumber,
    required this.passengerName,
    required this.gender,
    required this.primaryNic,
    required this.checkedIn,
  });

  factory TripPassenger.fromJson(Map<String, dynamic> json) {
    return TripPassenger(
      id: int.tryParse('${json['booking_passenger_id'] ?? json['id'] ?? 0}') ?? 0,
      seatNumber: '${json['seat_number'] ?? '-'}',
      passengerName: '${json['passenger_name'] ?? '-'}',
      gender: '${json['gender'] ?? '-'}',
      primaryNic: json['primary_passenger_nic']?.toString(),
      checkedIn: json['checked_in_at'] != null,
    );
  }
}
