import 'package:flutter/material.dart';

import '../models/trip.dart';
import '../services/api_service.dart';
import '../widgets/common.dart';
import 'trip_detail_screen.dart';

class TripsScreen extends StatefulWidget {
  final VoidCallback onBack;

  const TripsScreen({
    super.key,
    required this.onBack,
  });

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen> {
  List<Trip>? trips;
  Object? error;
  bool refreshing = false;

  @override
  void initState() {
    super.initState();
    loadTrips();
  }

  Future<void> loadTrips() async {
    try {
      if (mounted) {
        setState(() {
          refreshing = true;
        });
      }

      final result = await ApiService.trips();

      if (!mounted) {
        return;
      }

      setState(() {
        trips = result;
        error = null;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }

      setState(() {
        error = e;
        refreshing = false;
      });
    }
  }

  Future<void> openTrip(
    Trip trip,
  ) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TripDetailScreen(
          trip: trip,
        ),
      ),
    );

    if (!mounted) {
      return;
    }

    await loadTrips();
  }

  Color _statusColor(
    String status,
  ) {
    switch (status.toLowerCase()) {
      case 'active':
        return Colors.green;

      case 'completed':
        return Colors.blueGrey;

      case 'cancelled':
        return Colors.red;

      default:
        return const Color(
          0xFF064BD8,
        );
    }
  }

  String _statusText(
    String status,
  ) {
    switch (status.toLowerCase()) {
      case 'active':
        return 'ON TRIP';

      case 'completed':
        return 'COMPLETED';

      case 'scheduled':
        return 'SCHEDULED';

      default:
        return status.toUpperCase();
    }
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          onPressed: widget.onBack,
        ),
        title: const Text(
          "Today's / Upcoming Trips",
        ),
        actions: [
          IconButton(
            onPressed: refreshing ? null : loadTrips,
            icon: const Icon(
              Icons.refresh,
            ),
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(
            24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 48,
                color: Colors.red,
              ),
              const SizedBox(
                height: 12,
              ),
              Text(
                cleanError(
                  error!,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 12,
              ),
              ElevatedButton.icon(
                onPressed: loadTrips,
                icon: const Icon(
                  Icons.refresh,
                ),
                label: const Text(
                  'Retry',
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (trips == null) {
      return const LoadingView();
    }

    if (trips!.isEmpty) {
      return RefreshIndicator(
        onRefresh: loadTrips,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(
              height: 220,
            ),
            EmptyView(
              'No trips are currently assigned to this staff account.',
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: loadTrips,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(
          14,
        ),
        itemCount: trips!.length,
        itemBuilder: (
          context,
          index,
        ) {
          final trip = trips![index];

          return _buildTripCard(
            trip,
          );
        },
      ),
    );
  }

  Widget _buildTripCard(
    Trip trip,
  ) {
    final status = trip.status.toLowerCase();

    final statusColor = _statusColor(
      status,
    );

    return Card(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(
          12,
        ),
        onTap: () {
          openTrip(
            trip,
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(
            14,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(
                backgroundColor: Color(
                  0xFFE8F0FF,
                ),
                child: Icon(
                  Icons.directions_bus,
                  color: Color(
                    0xFF064BD8,
                  ),
                ),
              ),
              const SizedBox(
                width: 12,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${trip.origin} → ${trip.destination}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      '${trip.serviceDate} • ${trip.departureTime}',
                      style: const TextStyle(
                        color: Colors.black54,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      '${trip.busNumber} • '
                      '${trip.bookedPassengers}/${trip.seatCount} passengers',
                      style: const TextStyle(
                        color: Colors.black54,
                      ),
                    ),
                    if (status == 'active') ...[
                      const SizedBox(
                        height: 8,
                      ),
                      const Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 16,
                            color: Colors.green,
                          ),
                          SizedBox(
                            width: 4,
                          ),
                          Text(
                            'Live trip in progress',
                            style: TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 9,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(
                    alpha: 0.10,
                  ),
                  borderRadius: BorderRadius.circular(
                    20,
                  ),
                  border: Border.all(
                    color: statusColor.withValues(
                      alpha: 0.35,
                    ),
                  ),
                ),
                child: Text(
                  _statusText(
                    status,
                  ),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
