import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../widgets/common.dart';
import 'login_screen.dart';

class ProfileScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const ProfileScreen({
    super.key,
    this.onBack,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? me;
  Object? err;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final data = await ApiService.me();

      if (!mounted) {
        return;
      }

      setState(() {
        me = data;
        err = null;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }

      setState(() {
        err = e;
      });
    }
  }

  Future<void> logout() async {
    await ApiService.logout();

    if (!mounted) {
      return;
    }

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      ),
          (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          onPressed: widget.onBack ??
                  () {
                Navigator.pop(context);
              },
        ),
        title: const Text(
          'Staff Profile',
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (err != null) {
      return Center(
        child: Text(
          cleanError(err!),
        ),
      );
    }

    if (me == null) {
      return const LoadingView();
    }

    final String role =
        me!['role']?.toString().toLowerCase() ?? '';

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Center(
          child: CircleAvatar(
            radius: 48,
            child: Icon(
              Icons.person,
              size: 54,
            ),
          ),
        ),
        const SizedBox(
          height: 12,
        ),
        Center(
          child: Text(
            me!['full_name']?.toString() ?? '',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(
          height: 4,
        ),
        Center(
          child: Text(
            role.toUpperCase(),
            style: const TextStyle(
              color: Color(
                0xFF064BD8,
              ),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(
          height: 18,
        ),

        _profileItem(
          icon: Icons.badge,
          title: 'Login ID',
          value: me!['login_id']?.toString() ?? '-',
        ),

        _profileItem(
          icon: Icons.credit_card,
          title: 'NIC',
          value: me!['nic']?.toString() ?? '-',
        ),

        _profileItem(
          icon: Icons.phone,
          title: 'Phone',
          value: me!['phone']?.toString() ?? '-',
        ),

        _profileItem(
          icon: Icons.email,
          title: 'Email',
          value: me!['email']?.toString() ?? '-',
        ),

        if (role == 'driver')
          _profileItem(
            icon: Icons.drive_eta,
            title: 'Driving Licence',
            value:
            me!['driving_licence_no']?.toString() ?? '-',
          ),

        _profileItem(
          icon: Icons.verified_user,
          title: 'NTC Licence / ID',
          value: me!['ntc_licence_no']?.toString() ?? '-',
        ),

        const SizedBox(
          height: 12,
        ),

        const Card(
          child: ListTile(
            leading: Icon(
              Icons.info_outline,
              color: Color(
                0xFF064BD8,
              ),
            ),
            title: Text(
              'View-only Profile',
            ),
            subtitle: Text(
              'Protected staff information can only be changed '
                  'by your Bus Operator.',
            ),
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.red,
            minimumSize: const Size.fromHeight(
              48,
            ),
          ),
          onPressed: logout,
          icon: const Icon(
            Icons.logout,
          ),
          label: const Text(
            'Logout',
          ),
        ),
      ],
    );
  }

  Widget _profileItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(
          icon,
          color: const Color(
            0xFF064BD8,
          ),
        ),
        title: Text(
          title,
        ),
        subtitle: Text(
          value.isEmpty ? '-' : value,
        ),
      ),
    );
  }
}