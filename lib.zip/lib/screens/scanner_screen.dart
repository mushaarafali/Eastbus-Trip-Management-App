import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../services/trip_service.dart';

class ScannerScreen extends StatefulWidget {
  final int tripId;

  const ScannerScreen({
    super.key,
    required this.tripId,
  });

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final scanner = MobileScannerController();
  final service = TripService();

  bool processing = false;
  String? lastCode;

  Future<void> verify(String code) async {
    if (processing || code == lastCode) return;

    setState(() {
      processing = true;
      lastCode = code;
    });

    try {
      final response = await service.verifyTicket(widget.tripId, code);
      final data = Map<String, dynamic>.from(response as Map);
      final ticket = Map<String, dynamic>.from(data['ticket'] as Map);
      final passengers = (ticket['passengers'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();

      if (!mounted) return;

      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: ListView(
              shrinkWrap: true,
              children: [
                const Icon(
                  Icons.verified,
                  size: 54,
                ),
                const SizedBox(height: 10),
                const Text(
                  'Valid EastBus Ticket',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Booking: ${ticket['booking_reference'] ?? '-'}',
                ),
                Text(
                  'Primary Passenger: ${ticket['primary_passenger_name'] ?? '-'}',
                ),
                Text(
                  'Primary NIC: ${ticket['primary_passenger_nic'] ?? '-'}',
                ),
                Text(
                  'Boarding: ${ticket['boarding_stop'] ?? '-'}',
                ),
                Text(
                  'Drop-off: ${ticket['dropoff_stop'] ?? '-'}',
                ),
                const Divider(height: 28),
                ...passengers.map(
                  (passenger) => Card(
                    child: ListTile(
                      leading: Icon(
                        '${passenger['gender']}'.toLowerCase() == 'female'
                            ? Icons.woman
                            : Icons.man,
                      ),
                      title: Text(
                        '${passenger['passenger_name'] ?? '-'} • ${passenger['seat_number'] ?? '-'}',
                      ),
                      subtitle: Text(
                        'Gender: ${passenger['gender'] ?? '-'}',
                      ),
                      trailing: passenger['checked_in_at'] != null
                          ? const Icon(Icons.check_circle)
                          : FilledButton(
                              onPressed: () async {
                                final passengerId =
                                    int.tryParse('${passenger['id']}') ?? 0;

                                if (passengerId == 0) return;

                                try {
                                  await service.checkIn(
                                    widget.tripId,
                                    passengerId,
                                  );

                                  if (!context.mounted) return;
                                  Navigator.pop(context);

                                  ScaffoldMessenger.of(this.context)
                                      .showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        '${passenger['passenger_name']} checked in.',
                                      ),
                                    ),
                                  );
                                } catch (e) {
                                  if (!context.mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text(e.toString())),
                                  );
                                }
                              },
                              child: const Text('Check-in'),
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) {
        setState(() => processing = false);
      }

      Future.delayed(
        const Duration(seconds: 2),
        () => lastCode = null,
      );
    }
  }

  @override
  void dispose() {
    scanner.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Passenger QR'),
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: scanner,
            onDetect: (capture) {
              final value = capture.barcodes.firstOrNull?.rawValue;

              if (value != null && value.isNotEmpty) {
                verify(value);
              }
            },
          ),
          if (processing)
            const Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }
}
