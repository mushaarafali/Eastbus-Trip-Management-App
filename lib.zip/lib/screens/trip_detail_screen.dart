import 'package:flutter/material.dart';

import '../services/trip_service.dart';
import 'scanner_screen.dart';

class TripDetailScreen extends StatefulWidget {
  final int tripId;
  final String tripCode;
  final String route;
  final String status;

  const TripDetailScreen({
    super.key,
    required this.tripId,
    required this.tripCode,
    required this.route,
    required this.status,
  });

  @override
  State<TripDetailScreen> createState() => _TripDetailScreenState();
}

class _TripDetailScreenState extends State<TripDetailScreen> {
  final service = TripService();

  late String status;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    status = widget.status;
  }

  Future<void> startTrip() async {
    if (loading) return;

    setState(() => loading = true);

    try {
      await service.start(widget.tripId);

      if (!mounted) return;

      setState(() => status = 'active');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Trip started. Passenger booking is now closed.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> endTrip() async {
    if (loading) return;

    setState(() => loading = true);

    try {
      await service.end(widget.tripId);

      if (!mounted) return;

      setState(() => status = 'completed');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Trip completed.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = status == 'active';
    final completed = status == 'completed';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.tripCode),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            widget.route,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text('Status: ${status.toUpperCase()}'),
          const SizedBox(height: 20),
          if (!active && !completed)
            FilledButton.icon(
              onPressed: loading ? null : startTrip,
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start Trip'),
            ),
          if (active) ...[
            FilledButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ScannerScreen(
                    tripId: widget.tripId,
                  ),
                ),
              ),
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Scan Passenger QR'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: loading ? null : endTrip,
              icon: const Icon(Icons.stop_circle),
              label: const Text('End Trip'),
            ),
          ],
          if (completed)
            const Card(
              child: ListTile(
                leading: Icon(Icons.check_circle),
                title: Text('Trip Completed'),
              ),
            ),
        ],
      ),
    );
  }
}
