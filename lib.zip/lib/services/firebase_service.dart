import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trip.dart';

class FirebaseService {
  static final FirebaseDatabase _db = FirebaseDatabase.instance;

  static Future<String> _loginId() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('staff_login_id') ?? '';
  }

  static Future<List<Trip>> assignedTrips() async {
    final loginId = await _loginId();
    if (loginId.isEmpty) return [];
    final snap = await _db.ref('assigned_trips/$loginId').get();
    if (!snap.exists || snap.value is! Map) return [];
    final map = Map<dynamic, dynamic>.from(snap.value as Map);
    final trips = <Trip>[];
    for (final entry in map.entries) {
      if (entry.value is Map) {
        final j = Map<String, dynamic>.from(Map<dynamic, dynamic>.from(entry.value as Map));
        trips.add(Trip.fromJson(j));
      }
    }
    trips.sort((a,b) => '${a.serviceDate} ${a.departureTime}'.compareTo('${b.serviceDate} ${b.departureTime}'));
    return trips;
  }

  static Stream<DatabaseEvent> assignedTripsStream(String loginId) =>
      _db.ref('assigned_trips/$loginId').onValue;

  static Future<void> markTripStatus(Trip trip, String status) async {
    final loginId = await _loginId();
    if (loginId.isNotEmpty) {
      await _db.ref('assigned_trips/$loginId/${trip.tripCode}').update({
        'status': status,
        'updated_at': ServerValue.timestamp,
      });
    }
    await _db.ref('live_trips/${trip.tripCode}').update({
      'trip_id': trip.id,
      'trip_code': trip.tripCode,
      'bus_number': trip.busNumber,
      'origin': trip.origin,
      'destination': trip.destination,
      'staff_login_id': loginId,
      'status': status == 'active' ? 'ON_TRIP' : status.toUpperCase(),
      'updated_at': ServerValue.timestamp,
    });
  }

  static Future<void> updateLiveLocation({
    required Trip trip,
    required double latitude,
    required double longitude,
    required double speedKmh,
    required double heading,
  }) async {
    final loginId = await _loginId();
    await _db.ref('live_trips/${trip.tripCode}').update({
      'trip_id': trip.id,
      'trip_code': trip.tripCode,
      'bus_number': trip.busNumber,
      'origin': trip.origin,
      'destination': trip.destination,
      'staff_login_id': loginId,
      'latitude': latitude,
      'longitude': longitude,
      'speed': speedKmh,
      'heading': heading,
      'status': 'ON_TRIP',
      'updated_at': ServerValue.timestamp,
    });
  }

  static Future<void> emergency({
    required Trip trip,
    double? latitude,
    double? longitude,
    required String message,
  }) async {
    final loginId = await _loginId();
    await _db.ref('emergency_alerts').push().set({
      'trip_id': trip.id,
      'trip_code': trip.tripCode,
      'bus_number': trip.busNumber,
      'staff_login_id': loginId,
      'latitude': latitude,
      'longitude': longitude,
      'message': message,
      'status': 'OPEN',
      'created_at': ServerValue.timestamp,
    });
  }
}
