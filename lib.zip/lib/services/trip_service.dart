import 'api_service.dart';

class TripService {
  Future<dynamic> dashboard() =>
      ApiService.get('/staff/dashboard');

  Future<dynamic> trips() =>
      ApiService.get('/staff/trips');

  Future<dynamic> start(int tripId) =>
      ApiService.post('/staff/trips/$tripId/start', {});

  Future<dynamic> sendLocation(
    int tripId,
    double latitude,
    double longitude, {
    double? speed,
    double? heading,
    double? accuracy,
  }) =>
      ApiService.post('/staff/trips/$tripId/location', {
        'latitude': latitude,
        'longitude': longitude,
        if (speed != null) 'speed': speed,
        if (heading != null) 'heading': heading,
        if (accuracy != null) 'accuracy': accuracy,
      });

  Future<dynamic> passengers(int tripId) =>
      ApiService.get('/staff/trips/$tripId/passengers');

  Future<dynamic> end(int tripId) =>
      ApiService.post('/staff/trips/$tripId/end', {});

  Future<dynamic> verifyTicket(
    int tripId,
    String qrToken,
  ) =>
      ApiService.post('/staff/tickets/verify', {
        'trip_id': tripId,
        'qr_token': qrToken,
      });

  Future<dynamic> checkIn(
    int tripId,
    int bookingPassengerId,
  ) =>
      ApiService.post('/staff/tickets/check-in', {
        'trip_id': tripId,
        'booking_passenger_id': bookingPassengerId,
      });
}
