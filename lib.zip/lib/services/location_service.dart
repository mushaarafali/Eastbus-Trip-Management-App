import 'dart:async';

import 'package:geolocator/geolocator.dart';

import '../models/trip.dart';
import 'api_service.dart';
import 'firebase_service.dart';

class LocationService {
  StreamSubscription<Position>? _subscription;

  Future<bool> requestPermission() async {
    final bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      return false;
    }

    return permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse;
  }

  Future<Position?> current() async {
    final bool allowed = await requestPermission();

    if (!allowed) {
      return null;
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
      ),
    );
  }

  Future<void> startSharing(
    Trip trip,
  ) async {
    final bool allowed = await requestPermission();

    if (!allowed) {
      throw Exception(
        'Location permission is required.',
      );
    }

    await stop();

    final AndroidSettings settings = AndroidSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
      intervalDuration: Duration(
        seconds: 10,
      ),
      foregroundNotificationConfig: ForegroundNotificationConfig(
        notificationTitle: 'EastBus Live Trip',
        notificationText: 'Sharing bus location while the trip is active',
        enableWakeLock: true,
      ),
    );

    _subscription = Geolocator.getPositionStream(
      locationSettings: settings,
    ).listen(
      (Position position) async {
        await _shareLocation(
          trip,
          position,
        );
      },
      onError: (Object error) {
        // Location stream errors can be logged here if needed.
      },
    );
  }

  Future<void> _shareLocation(
    Trip trip,
    Position position,
  ) async {
    final double speedKmh = position.speed < 0 ? 0.0 : position.speed * 3.6;

    final double heading = position.heading < 0 ? 0.0 : position.heading;

    try {
      await FirebaseService.updateLiveLocation(
        trip: trip,
        latitude: position.latitude,
        longitude: position.longitude,
        speedKmh: speedKmh,
        heading: heading,
      );
    } catch (_) {
      // Firebase failure should not stop
      // the live location stream.
    }

    try {
      await ApiService.sendLocation(
        trip.id,
        position.latitude,
        position.longitude,
        speedKmh,
        heading: heading,
      );
    } catch (_) {
      // API failure should not stop
      // Firebase location sharing.
    }
  }

  Future<void> stop() async {
    await _subscription?.cancel();

    _subscription = null;
  }

  bool get isSharing => _subscription != null;
}
